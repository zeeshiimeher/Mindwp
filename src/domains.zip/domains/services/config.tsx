import type { ReactElement } from 'react';

import { CTARegistryProvider } from '@/components/system/PageEnforcement';
import { SmartRelatedSection } from '@/components/system/SmartRelatedSection';
import { aiLeadHandlingPage } from '@/domains/services/data/ai-lead-handling';
import { bricksBuilderPage } from '@/domains/services/data/bricks-builder';
import { conversionFunnelSystemVsLandingPageDevelopmentPage } from '@/domains/services/data/conversion-funnel-system-vs-landing-page-development';
import { conversionLayerPage } from '@/domains/services/data/conversion-layer';
import { crmAutomationPage } from '@/domains/services/data/crm-automation';
import { divi5Page } from '@/domains/services/data/divi5';
import { elementorPage } from '@/domains/services/data/elementor';
import { leadReactivationSystemPage } from '@/domains/services/data/lead-reactivation-system';
import { localSeoAuthorityPage } from '@/domains/services/data/local-seo-authority';
import { missedCallRecoverySystemPage } from '@/domains/services/data/missed-call-recovery-system';
import { reputationReviewSystemsPage } from '@/domains/services/data/reputation-review-systems';
import { servicePagesVsOneGenericServicesPage } from '@/domains/services/data/service-pages-vs-one-generic-services-page';
import { smartWebsiteSystemsPage } from '@/domains/services/data/smart-website-systems';
import { systemMigrationPlatformConsolidationPage } from '@/domains/services/data/system-migration-platform-consolidation';
import { unifiedCommunicationSystemPage } from '@/domains/services/data/unified-communication-system';
import { websiteCrmIntegrationVsManualLeadHandlingPage } from '@/domains/services/data/website-crm-integration-vs-manual-lead-handling';
import { websiteRedesignSystemRebuildPage } from '@/domains/services/data/website-redesign-system-rebuild';
import { woocommercePage } from '@/domains/services/data/woocommerce';
import { wordpressDevelopmentPage } from '@/domains/services/data/wordpress-development';
import { AiLeadHandlingRenderer } from '@/domains/services/renderers/AiLeadHandlingRenderer';
import { BricksBuilderRenderer } from '@/domains/services/renderers/BricksBuilderRenderer';
import { ConversionLayerRenderer } from '@/domains/services/renderers/ConversionLayerRenderer';
import { CRMAutomationRenderer } from '@/domains/services/renderers/CRMAutomationRenderer';
import { Divi5Renderer } from '@/domains/services/renderers/Divi5Renderer';
import { ElementorRenderer } from '@/domains/services/renderers/ElementorRenderer';
import { LeadReactivationSystemRenderer } from '@/domains/services/renderers/LeadReactivationSystemRenderer';
import { LocalSeoAuthorityRenderer } from '@/domains/services/renderers/LocalSeoAuthorityRenderer';
import { MissedCallRecoverySystemRenderer } from '@/domains/services/renderers/MissedCallRecoverySystemRenderer';
import { ReputationReviewSystemsRenderer } from '@/domains/services/renderers/ReputationReviewSystemsRenderer';
import SmartWebsiteSystemsRenderer from '@/domains/services/renderers/SmartWebsiteSystemsRenderer';
import { SystemMigrationPlatformConsolidationRenderer } from '@/domains/services/renderers/SystemMigrationPlatformConsolidationRenderer';
import { UnifiedCommunicationSystemRenderer } from '@/domains/services/renderers/UnifiedCommunicationSystemRenderer';
import { WebsiteRedesignSystemRebuildRenderer } from '@/domains/services/renderers/WebsiteRedesignSystemRebuildRenderer';
import { WooCommerceRenderer } from '@/domains/services/renderers/WooCommerceRenderer';
import { WordPressDevelopmentRenderer } from '@/domains/services/renderers/WordPressDevelopmentRenderer';

type ServiceEntry<TData> = {
  data: TData;
  render: (data: TData, slug: string) => ReactElement;
};

const createServiceEntry = <TData,>(
  data: TData,
  render: (data: TData, slug: string) => ReactElement
): ServiceEntry<TData> => ({ data, render });

function renderServiceEntry(slug: ServiceSlug): ReactElement {
  const entry = SERVICE_ENTRY_BY_SLUG_WITH_ALIASES[slug];
  const render = entry.render as (data: typeof entry.data, slug: string) => ReactElement;

  return (
    <CTARegistryProvider pageId={`service:${slug}`} pageType='service'>
      {render(entry.data, slug)}
      <SmartRelatedSection slug={slug} />
    </CTARegistryProvider>
  );
}

export const SERVICE_ENTRY_BY_SLUG = {
  'smart-website-systems': createServiceEntry(smartWebsiteSystemsPage, (data, slug) => (
    <SmartWebsiteSystemsRenderer data={data} slug={slug} />
  )),
  'conversion-layer': createServiceEntry(conversionLayerPage, (data, slug) => (
    <ConversionLayerRenderer data={data} slug={slug} />
  )),
  'conversion-funnel-system-vs-landing-page-development': createServiceEntry(
    conversionFunnelSystemVsLandingPageDevelopmentPage,
    (data, slug) => <ConversionLayerRenderer data={data} slug={slug} />
  ),
  'system-migration-platform-consolidation': createServiceEntry(
    systemMigrationPlatformConsolidationPage,
    (data, slug) => <SystemMigrationPlatformConsolidationRenderer data={data} slug={slug} />
  ),
  'website-redesign-system-rebuild': createServiceEntry(
    websiteRedesignSystemRebuildPage,
    (data, slug) => <WebsiteRedesignSystemRebuildRenderer data={data} slug={slug} />
  ),
  'lead-reactivation-system': createServiceEntry(leadReactivationSystemPage, (data, slug) => (
    <LeadReactivationSystemRenderer data={data} slug={slug} />
  )),
  'missed-call-recovery-system': createServiceEntry(missedCallRecoverySystemPage, (data, slug) => (
    <MissedCallRecoverySystemRenderer data={data} slug={slug} />
  )),
  'unified-communication-system': createServiceEntry(
    unifiedCommunicationSystemPage,
    (data, slug) => <UnifiedCommunicationSystemRenderer data={data} slug={slug} />
  ),
  'local-seo-authority': createServiceEntry(localSeoAuthorityPage, (data, slug) => (
    <LocalSeoAuthorityRenderer data={data} slug={slug} />
  )),
  'reputation-review-systems': createServiceEntry(reputationReviewSystemsPage, (data, slug) => (
    <ReputationReviewSystemsRenderer data={data} slug={slug} />
  )),
  'crm-infrastructure-implementation': createServiceEntry(crmAutomationPage, (data, slug) => (
    <CRMAutomationRenderer data={data} slug={slug} />
  )),
  'website-crm-integration-vs-manual-lead-handling': createServiceEntry(
    websiteCrmIntegrationVsManualLeadHandlingPage,
    (data, slug) => <CRMAutomationRenderer data={data} slug={slug} />
  ),
  'ai-lead-handling': createServiceEntry(aiLeadHandlingPage, (data, slug) => (
    <AiLeadHandlingRenderer data={data} slug={slug} />
  )),
  'service-pages-vs-one-generic-services-page': createServiceEntry(
    servicePagesVsOneGenericServicesPage,
    (data, slug) => <SmartWebsiteSystemsRenderer data={data} slug={slug} />
  ),
  'wordpress-development': createServiceEntry(wordpressDevelopmentPage, (data, slug) => (
    <WordPressDevelopmentRenderer data={data} slug={slug} />
  )),
  ecommerce: createServiceEntry(woocommercePage, (data, slug) => (
    <WooCommerceRenderer data={data} slug={slug} />
  )),
  divi5: createServiceEntry(divi5Page, (data, slug) => <Divi5Renderer data={data} slug={slug} />),
  'bricks-builder': createServiceEntry(bricksBuilderPage, (data, slug) => (
    <BricksBuilderRenderer data={data} slug={slug} />
  )),
  elementor: createServiceEntry(elementorPage, (data, slug) => (
    <ElementorRenderer data={data} slug={slug} />
  )),
} as const;

export const SERVICE_ENTRY_ALIASES_BY_SLUG = {} as const;

export const SERVICE_ENTRY_BY_SLUG_WITH_ALIASES = {
  ...SERVICE_ENTRY_BY_SLUG,
  ...SERVICE_ENTRY_ALIASES_BY_SLUG,
} as const;

export type ServiceSlug = keyof typeof SERVICE_ENTRY_BY_SLUG_WITH_ALIASES;

export const isServiceSlug = (slug: string): slug is ServiceSlug => {
  return slug in SERVICE_ENTRY_BY_SLUG_WITH_ALIASES;
};

export const getServiceDataBySlug = (slug: ServiceSlug) => {
  return SERVICE_ENTRY_BY_SLUG_WITH_ALIASES[slug].data;
};

export const getServiceRendererBySlug = (slug: ServiceSlug) => {
  return SERVICE_ENTRY_BY_SLUG_WITH_ALIASES[slug].render;
};

export const renderServicePageBySlug = (slug: ServiceSlug): ReactElement => {
  switch (slug) {
    case 'smart-website-systems': {
      return renderServiceEntry(slug);
    }
    case 'conversion-layer': {
      return renderServiceEntry(slug);
    }
    case 'conversion-funnel-system-vs-landing-page-development': {
      return renderServiceEntry(slug);
    }
    case 'system-migration-platform-consolidation': {
      return renderServiceEntry(slug);
    }
    case 'website-redesign-system-rebuild': {
      return renderServiceEntry(slug);
    }
    case 'lead-reactivation-system': {
      return renderServiceEntry(slug);
    }
    case 'missed-call-recovery-system': {
      return renderServiceEntry(slug);
    }
    case 'unified-communication-system': {
      return renderServiceEntry(slug);
    }
    case 'local-seo-authority': {
      return renderServiceEntry(slug);
    }
    case 'reputation-review-systems': {
      return renderServiceEntry(slug);
    }
    case 'crm-infrastructure-implementation': {
      return renderServiceEntry(slug);
    }
    case 'website-crm-integration-vs-manual-lead-handling': {
      return renderServiceEntry(slug);
    }
    case 'ai-lead-handling': {
      return renderServiceEntry(slug);
    }
    case 'service-pages-vs-one-generic-services-page': {
      return renderServiceEntry(slug);
    }
    case 'wordpress-development': {
      return renderServiceEntry(slug);
    }
    case 'ecommerce': {
      return renderServiceEntry(slug);
    }
    case 'divi5': {
      return renderServiceEntry(slug);
    }
    case 'bricks-builder': {
      return renderServiceEntry(slug);
    }
    case 'elementor': {
      return renderServiceEntry(slug);
    }
  }
};

export const getSlugFromCanonical = (canonical: string) => {
  const segments = canonical.split('/').filter(Boolean);
  return segments[segments.length - 1] ?? '';
};
